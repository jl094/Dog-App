﻿var ViewModel = function () {
    var self = this;
    self.dogs = ko.observableArray();
    self.error = ko.observable();
    //self.detail = ko.observable();
    self.edit = ko.observable();
    //self.getDogDetail = function (item) {
    //    ajaxHelper(dogsUri + item.Id, 'GET').done(function (data) {
    //        self.detail(data);
    //    });
    //}
    self.newDog = {
        Breed: ko.observable(),
        SubBreed: ko.observable()
    }
    self.addDog = function (formElement) {
        var dog = {
            Breed: self.newDog.Breed(),
            SubBreed: self.newDog.SubBreed()
        };

        ajaxHelper(dogsUri, 'POST', dog).done(function (item) {
            self.dogs.push(item);
        })
    }
    self.deleteDog = function (item) {
        ajaxHelper(dogsUri + item.Id, 'DELETE').done(function (item) {
            for (var i = 0; i < self.dogs.length; i++) {
                if (self.dogs[i].Id === item.Id) {
                    self.dogs.splice(i, 1);
                    break;
                }
            }
            getAllDogs();
        });
    }
    self.editDogDetail = function (item) {
        ajaxHelper(dogsUri + item.Id, 'GET').done(function (data) {
            self.edit(data);
        });
    }
    //self.updatedDog = {
    //    Breed: ko.observable(),
    //    SubBreed: ko.observable()
    //}
    self.updateDog = function (formElement) {
        var dog = {
            Breed: self.edit.Breed(),
            SubBreed: self.edit.SubBreed()
        };

        ajaxHelper(dogsUri + self.edit.Id(), 'PUT', dog).done(function (item) {
            getAllDogs();
        })
    }

    var dogsUri = '/api/dogs/';

    function ajaxHelper(uri, method, data) {
        self.error('');
        return $.ajax({
            type: method,
            url: uri,
            dataType: 'json',
            contentType: 'application/json',
            data: data ? JSON.stringify(data) : null
        }).fail(function (jqXHR, textStatus, errorThrown) {
            self.error(errorThrown);
        })
    }

    function getAllDogs() {
        ajaxHelper(dogsUri, 'GET').done(function (data) {
            self.dogs(data)
        });
    }

    getAllDogs();
};

ko.applyBindings(new ViewModel());